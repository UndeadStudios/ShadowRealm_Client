# Exilius client
## Run arguments
* --local/-l: localhost connection
* --developer/-d: developer mode

## Developer mode
Developer modes give you the ability to have a cache placed inside the client directory at `/client/local_cache/`. 
It also allows you to use developer commands (also enabled if you have the developer rank in-game) and prints out some warnings that otherwise aren't shown.